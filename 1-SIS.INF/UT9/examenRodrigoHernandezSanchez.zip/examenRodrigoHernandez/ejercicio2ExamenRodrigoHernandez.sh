#!/bin/bash

sudo echo "Se va a proceder a crear el directorio de planos para el año 2026"
sudo chmod 621 examenRodrigoHernandezSanchez.sh
sudo bash examenRodrigoHernandezSanchez.sh
sudo cd $HOME/planos2026
sudo /tree


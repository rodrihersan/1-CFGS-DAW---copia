#!/bin/bash

#Punto2-3
sudo useradd -m arquitecto
sudo useradd -m perito
sudo useradd -m tecnico
sudo useradd -m becario

#Punto4
sudo cd $HOME
sudo mkdir $HOME/planos2026
sudo mkdir $HOME/planos2026/proyectosAprobados
sudo mkdir $HOME/planos2026/proyectosAPresupuestar
sudo mkdir $HOME/planos2026/descartes

#Punto5

sudo touch $HOME/planos2026/proyectosAprobados/archivo1.txt
sudo touch $HOME/planos2026/proyectosAPresupuestar/archivo2.txt
sudo mkdir $HOME/planos2026/descartes/archivo3.txt
sudo echo "Documentación de los proyectos del año 2026" >> $HOME/planos2026/proyectosAprobados/archivo1.txt
sudo echo "Documentación de los proyectos del año 2026" >> $HOME/planos2026/proyectosAPresupuestar/archivo2.txt
sudo echo "Documentación de los proyectos del año 2026" >> $HOME/planos2026/descartes/archivo3.txt

#Punto6
sudo groupadd peritoTecnicoBecario 
sudo usermod -aG peritoTecnicoBecario perito
sudo usermod -aG peritoTecnicoBecario tecnico
sudo usermod -aG peritoTecnicoBecario becario

sudo groupadd peritoTecnico
sudo usermod -aG peritoTecnico perito
sudo usermod -aG peritoTecnico tecnico
sudo chown arquitecto:peritoTecnicoBecario $HOME/planos2026
sudo chown :peritoTecnico $HOME/planos2026/proyectosAPresupuestar

sudo chmod -R 640 $HOME/planos2026
sudo chmod -R 060 $HOME/planos2026/proyectosApresupuestar
